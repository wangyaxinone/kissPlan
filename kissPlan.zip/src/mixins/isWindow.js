export default {
    data(){
        return {
            isWindow:false,
        }
    },
    mounted() {
        this.isWindow = true;
    },
}