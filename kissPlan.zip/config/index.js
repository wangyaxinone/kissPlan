module.exports = {
    baseUrl:process.env.NODE_ENV !== 'development' ?'http://admin.jsercode.com:3002':'http://192.168.0.103:3002'
}