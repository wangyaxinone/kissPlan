<template>
    <div class="Advertisement">
        <a href="https://dsp-click.youdao.com/clk/request.s?slot=5dc7c0eb459a12bc99cb30cf2d7fc358&amp;k=9usVNZYygri1cBtmRbYbFA6LsvPyAooUaLmMUsfTiULXxo%2BoRxcJpjjAgKuViCqvIxCHqA9N%2F2c%2F9Be%2FcwcSr%2F41p17%2BINqIAltgtrn2lhODUcIfrTGc4TKC4SroHeKjOZwDWTQGeBHgvwl94dlWyK466rmi%2BFABmQWmV24t%2Br%2FR%2FDnbe99mekKt%2BtF2758zeFfbVF%2FQ4jjW8F%2FV%2FeG2NPNEZv4i9Mtxo7WICsWX0HzRkMUzUIaQ9xcakySYi4Wth5un9v%2BGV9LbPnxWrNTQbhPafGaZmin0hzosV497uvsPMPW42KJ9hSpgZPPkFVxLUa2Nth%2F0lVcrBrgiZBiNlMZ%2FouYuc9UXwdIMSWMLmh6uRRC3%2BG%2BnXeuPYUj09Fs4oIgnCdZPPu3Xpj%2BhC6OlSTkYdwWXeegvj7mVynb2Jt%2FPOHp%2FQL8hswCU%2BqDmNTmaFXM6KcO3ivJujY%2BOllZ2jFzri9%2BLZluu2fcOY4lLCnhqqcA6JH%2FJVh3hDi2DUTpbsr2HhRpY%2FIEFNGn%2F3oyHEVvEoR7lwa1B22Rt1i%2F86J7e1Il42XGVz92mvfLUdJTMF6%2BQQlbnsahtigls8K7DiCIx4fMH%2F8ZbweBNklpMTmweZhWez%2BCxqKCiOJl3Z1vX6rk47LEhd2CX%2BVX60gRgaD1KeJWSqBeYi39GE5P%2BY%2F8PXG%2B6qmVKifGHnfLJWOmSxren7PPm7QLTJCvMX1UvBfm9FeAm7NX4pcBFblPNgqxbA0mMQVzXIMXewBTIR6o6UTYP39uJWgGOvVxypJgMwbX6%2BjKdnxB1au83z8Vqtg43FtoViFFYDIJhEvoGrWQXlk1JDARoF9IqUkrmaMaDn1C32SVYz0VnoJ2ROLfw72a03xq3TUT3IKWahwLudbQMvYJPDD3Q2C1GHywmrYV5s7QgSuyYB3Fe2FvvqVD%2FNNNcaInJ2tdzxNNr9OMFNXjSF7OUdKm0h3P1%2BadurfqtkEnNoWHpJ5euJ%2F08mcNDqN7W%2BsnzyWgrOecl6wgGFJzFE8h%2Bq2lC8z5%2FDN4Rb3GUHNfGj6hHFwmmOMCAq5WIKq%2FXxo%2BoRxcJpjjAgKuViCqv2aYyPiOGt8Y19MYRl5oULjrgka0NYN%2Bf4BDkS2aU%2Ffs%3D&amp;youdao_bid=f2a01db4-cf18-4eea-890b-60c21db7a351&amp;iid=%7B%222250928659533423454%22%3A4%7D&amp;sid=17170" target="_blank" class="youdao-img-ad ad-1" style="background-image: url(&quot;https://oimagea3.ydstatic.com/image?id=2250928659533423454&amp;product=adpublish&amp;w=1280&amp;h=720&amp;sc=0&amp;rm=2&amp;gsb=0&amp;gsbd=60&quot;);"><span class="ad-badge">广告</span></a>
    </div>
</template>
<script>
export default {
    name:'Advertisement',
    data(){
        return {

        }
    }
}
</script>
<style lang="less" scoped>
    .Advertisement{
        a{
            position: relative;
            border-radius: 4px;
            display: block;
            background-position: center;
            background-size: cover;
            background-repeat: no-repeat;
            height: 160px;
            width: 100%;
            margin-bottom: 20px;
            overflow: hidden;
            background-color: RGB(241, 243, 244);
        }
    }
</style>
