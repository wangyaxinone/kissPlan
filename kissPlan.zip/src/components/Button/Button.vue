<template>
    <span class="my-button">
        <solt></solt>
    </span>
</template>
<script>
export default {
    name:'k-button',
    data:function(){
        return {

        }
    }
}
</script>
<style lang="less">
    .my-button{

    }
</style>

