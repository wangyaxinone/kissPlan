export default {
    computed: {
        pSize() {
            return this.$store.state.pageSize
        }
    },
}