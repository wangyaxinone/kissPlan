<template>
    <div class="zanShang">
        <mu-button color="error" round>打赏</mu-button>
    </div>
</template>
<script>
export default {
    name:'zanShang',
    data(){
        return {

        }
    }
}
</script>
<style lang="less">
    .zanShang{
        text-align: center;
    }
</style>

