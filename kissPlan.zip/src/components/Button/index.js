import Vue from "./node_modules/vue"
import Button from "./Button.vue"
Vue.component('k-button',Button)