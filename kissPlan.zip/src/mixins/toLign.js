export default {
    methods:{
        toLogin(){
            this.$router.push('/login')
        }
    }
}